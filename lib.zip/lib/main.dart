// main.dart
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:path_provider/path_provider.dart';
import 'package:stoqle/index/splash.dart';
import 'package:toast/toast.dart';
import 'config/app_routes.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/provider/auth_provider.dart';
import 'firebase_options.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // background handler runs in its own isolate
  await Firebase.initializeApp();
  // If you want to display a local notification from background handler,
  // note: setting 'notification' on server payload typically lets OS show it.
  print("Handling a background message: ${message.messageId}");
}

final RouteObserver<PageRoute<dynamic>> routeObserver =
    RouteObserver<PageRoute<dynamic>>();

/// Local notifications plugin (global)
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

const String highImportanceChannelId = 'high_importance_channel';
const String highImportanceChannelName = 'Important Notifications';
const String highImportanceChannelDescription =
    'Channel for important notifications (heads-up).';

final Dio _dio = Dio()
  ..options.connectTimeout = const Duration(seconds: 8)
  ..options.receiveTimeout = const Duration(seconds: 10);

/// Downloader using Dio (simple bytes) - good for small images
Future<String?> downloadAndSaveFileWithDio(String url, String fileName) async {
  try {
    final dir = await getTemporaryDirectory();
    final filePath = '${dir.path}/$fileName';

    final response = await _dio.get<List<int>>(
      url,
      options: Options(responseType: ResponseType.bytes),
    );

    final bytes = response.data;
    if (bytes == null || bytes.isEmpty) return null;

    final file = File(filePath);
    await file.writeAsBytes(bytes, flush: true);
    return filePath;
  } catch (e) {
    debugPrint('Dio download error: $e');
    return null;
  }
}

/// Initialize local notifications and create Android channel with custom sound
Future<void> _initializeLocalNotifications() async {
  const AndroidInitializationSettings androidInit =
      AndroidInitializationSettings('@mipmap/ic_launcher');

  final DarwinInitializationSettings iosInit = DarwinInitializationSettings(
    requestSoundPermission: true,
    requestBadgePermission: true,
    requestAlertPermission: true,
  );

  final InitializationSettings initSettings = InitializationSettings(
    android: androidInit,
    iOS: iosInit,
  );

  await flutterLocalNotificationsPlugin.initialize(
    initSettings,
    onDidReceiveNotificationResponse: (NotificationResponse response) {
      // handle notification tap
      debugPrint('local notification tapped: ${response.payload}');
    },
  );

  // Create Android channel with custom raw sound 'beep' (beep.mp3 in res/raw)
  final androidChannel = AndroidNotificationChannel(
    highImportanceChannelId,
    highImportanceChannelName,
    description: highImportanceChannelDescription,
    importance: Importance.max,
    playSound: true,
    sound: RawResourceAndroidNotificationSound(
      'beep',
    ), // matches android res/raw/beep.mp3 (name only)
    enableVibration: true,
    showBadge: true,
  );

  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin
      >()
      ?.createNotificationChannel(androidChannel);
}

/// Show a local notification (foreground case) — downloads image if present
Future<void> showLocalNotification(RemoteMessage message) async {
  final notification = message.notification;
  final data = message.data;

  final title = notification?.title ?? data['title'] ?? '';
  final body = notification?.body ?? data['body'] ?? '';
  // prefer data['image'] (server sets image in data) but fall back to notification fields
  final imageUrl = (data['image'] ?? notification?.android?.imageUrl)
      ?.toString();

  // Android details: BigPicture style when image present
  AndroidNotificationDetails androidDetails;
  if (imageUrl != null && imageUrl.isNotEmpty) {
    final bigPicturePath = await downloadAndSaveFileWithDio(
      imageUrl,
      'notif_image_${DateTime.now().millisecondsSinceEpoch}.png',
    );

    if (bigPicturePath != null) {
      final bigPictureStyle = BigPictureStyleInformation(
        FilePathAndroidBitmap(bigPicturePath),
        largeIcon: FilePathAndroidBitmap(bigPicturePath),
        contentTitle: title,
        summaryText: body,
      );

      androidDetails = AndroidNotificationDetails(
        highImportanceChannelId,
        highImportanceChannelName,
        channelDescription: highImportanceChannelDescription,
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        sound: RawResourceAndroidNotificationSound(
          'beep',
        ), // custom beep (res/raw/beep.mp3)
        styleInformation: bigPictureStyle,
        fullScreenIntent:
            false, // set true if you want to attempt full-screen (use with care)
      );
    } else {
      // fallback if download failed
      androidDetails = AndroidNotificationDetails(
        highImportanceChannelId,
        highImportanceChannelName,
        channelDescription: highImportanceChannelDescription,
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('beep'),
      );
    }
  } else {
    // no image
    androidDetails = AndroidNotificationDetails(
      highImportanceChannelId,
      highImportanceChannelName,
      channelDescription: highImportanceChannelDescription,
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('beep'),
    );
  }

  // iOS details: include attachment if image downloaded
  DarwinNotificationDetails iosDetails;
  if (imageUrl != null && imageUrl.isNotEmpty) {
    final attachmentPath = await downloadAndSaveFileWithDio(
      imageUrl,
      'notif_attachment_${DateTime.now().millisecondsSinceEpoch}.jpg',
    );
    if (attachmentPath != null) {
      final attachment = DarwinNotificationAttachment(attachmentPath);
      iosDetails = DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
        sound: 'beep.aiff', // make sure iOS bundle has this file
        attachments: [attachment],
      );
    } else {
      iosDetails = const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
        sound: 'beep.aiff',
      );
    }
  } else {
    iosDetails = const DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'beep.aiff',
    );
  }

  final platformDetails = NotificationDetails(
    android: androidDetails,
    iOS: iosDetails,
  );

  await flutterLocalNotificationsPlugin.show(
    DateTime.now().millisecondsSinceEpoch.remainder(100000),
    title,
    body,
    platformDetails,
    payload: data.isNotEmpty ? data.toString() : null,
  );
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // init local notifications & channel
  await _initializeLocalNotifications();

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String? _fcmToken;

  @override
  void initState() {
    super.initState();
    _initFCM();
    ToastContext().init(context);
  }

  void _initFCM() async {
    // Request permission (iOS)

    // For iOS: show notifications when app in foreground
    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
          alert: true,
          badge: true,
          sound: true,
        );

    _fcmToken = await FirebaseMessaging.instance.getToken();
    debugPrint("FCM Token: $_fcmToken");

    // Foreground messages - show local notification (so it pops up + plays custom sound)
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      debugPrint(
        "Message received in foreground: ${message.notification?.title}",
      );
      showLocalNotification(message);
    });

    // When user taps on notification (background -> opened)
    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      debugPrint("User tapped on notification: ${message.notification?.title}");
      // handle navigation using message.data
    });
  }

  @override
  Widget build(BuildContext context) {
    final brightness = MediaQuery.of(context).platformBrightness;
    final isDarkMode = brightness == Brightness.dark;

    return MaterialApp(
      navigatorObservers: [routeObserver],
      debugShowCheckedModeBanner: false,

      title: 'Stoqle',
      theme: isDarkMode ? AppTheme.darkTheme : AppTheme.lightTheme,
      home: const AuthGate(),
      routes: routes,
    );
  }
}

class AuthGate extends ConsumerWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authServiceProvider);

    debugPrint(
      'AuthGate - isLoading: ${auth.isLoading}, isLoggedIn: ${auth.isLoggedIn}, token: ${auth.token}',
    );

    if (auth.isLoading) {
      return SplashScreen();
    }

    if (auth.isLoggedIn) {
      final dashboardBuilder = routes['/dashboard'];
      if (dashboardBuilder != null) {
        return dashboardBuilder(context);
      }
      return const Scaffold(body: Center(child: Text('Dashboard not found')));
    }

    final introBuilder = routes['/intro'];
    if (introBuilder != null) {
      return introBuilder(context);
    }

    return const Scaffold(
      body: Center(child: Text('App route configuration error')),
    );
  }
}
