// user_navigator.dart
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:stoqle/core/widget/capturing-live.dart';
import 'package:stoqle/core/widget/gallery-sheet.dart';
import 'package:stoqle/features/view/market/markeplece.dart';
import '../../../component/colors/color.dart';
import '../../../features/view/gallery/selected_assets_page.dart';
import '../../../features/view/home/dashboard.dart';
import '../../../features/view/message/message-selection.dart';
import '../../../features/view/profile/me/me.dart';

class Usernavigator extends StatefulWidget {
  @override
  _UsernavigatorState createState() => _UsernavigatorState();
}

class _UsernavigatorState extends State<Usernavigator>
    with AutomaticKeepAliveClientMixin {
  int _selectedIndex = 0;

  final _pageOptions = [
    Dashboard(),
    MarketPlace(),
    Container(), // placeholder for plus (we open sheet instead)
    MessageDashboard(),
    ProfileMe(),
  ];

  void _onItemTapped(int index) async {
    if (index == 2) {
      // open your apple-style media action sheet
      final result = await showAppleStyleMediaSheet(context, maxAssets: 20);

      if (result == null) {
        // user cancelled, do nothing
        return;
      }

      // if user picked from album (wechat_assets_picker returns List<AssetEntity>)
      if (result is List<AssetEntity>) {
        if (result.isNotEmpty) {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => SelectedAssetsPage(assets: result),
            ),
          );
        }
        return;
      }

      if (result is XFile) {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => CapturedPreviewPage(filePath: result.path),
          ),
        );
        return;
      }

      // fallback: if some other type, just print it
      debugPrint('Media sheet returned: ${result.runtimeType}');
      return;
    }

    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      body: _pageOptions[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(PhosphorIcons.houseSimple(), size: 20),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(PhosphorIcons.storefront(), size: 20),
            label: 'Market',
          ),
          BottomNavigationBarItem(
            icon: Container(
              width: 50,
              height: 35,
              decoration: BoxDecoration(
                color: AppColors.kDefault,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(PhosphorIconsBold.plus, color: Colors.white),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(PhosphorIcons.chatCircleDots(), size: 20),
            label: 'Messages',
          ),
          BottomNavigationBarItem(
            icon: Icon(PhosphorIcons.user(), size: 20),
            label: 'Me',
          ),
        ],
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
