// selected_assets_page.dart
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:video_player/video_player.dart';

import '../../../component/loader/custom_loader.dart';

class SelectedAssetsPage extends StatefulWidget {
  final List<AssetEntity> assets;
  SelectedAssetsPage({required this.assets});

  @override
  _SelectedAssetsPageState createState() => _SelectedAssetsPageState();
}

class _SelectedAssetsPageState extends State<SelectedAssetsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Selected (${widget.assets.length})')),
      body: GridView.builder(
        padding: EdgeInsets.all(4),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4,
          mainAxisSpacing: 4,
        ),
        itemCount: widget.assets.length,
        itemBuilder: (context, index) {
          final asset = widget.assets[index];
          return FutureBuilder<Uint8List?>(
            future: asset.thumbnailDataWithSize(ThumbnailSize(200, 200)),
            builder: (context, snap) {
              final bytes = snap.data;
              if (bytes == null) {
                return Center(child: Container());
              }
              final isVideo = asset.type == AssetType.video;
              return GestureDetector(
                onTap: () async {
                  if (isVideo) {
                    final file = await asset.file;
                    if (file == null) return;
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => _VideoPlayerPage(videoFile: file),
                      ),
                    );
                  } else {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => _ImageViewerPage(asset: asset),
                      ),
                    );
                  }
                },
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: Image.memory(bytes, fit: BoxFit.cover),
                    ),
                    if (isVideo)
                      Positioned(
                        top: 6,
                        right: 6,
                        child: Icon(
                          Icons.play_circle_fill,
                          color: Colors.white,
                          size: 28,
                        ),
                      ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _ImageViewerPage extends StatelessWidget {
  final AssetEntity asset;
  _ImageViewerPage({required this.asset});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Image')),
      body: FutureBuilder<Uint8List?>(
        future: asset.originBytes,
        builder: (context, snap) {
          final bytes = snap.data;
          if (bytes == null)
            return Center(child: CustomCircularProgressIndicator());
          return Center(child: Image.memory(bytes));
        },
      ),
    );
  }
}

class _VideoPlayerPage extends StatefulWidget {
  final File videoFile;
  _VideoPlayerPage({required this.videoFile});

  @override
  __VideoPlayerPageState createState() => __VideoPlayerPageState();
}

class __VideoPlayerPageState extends State<_VideoPlayerPage> {
  late VideoPlayerController _controller;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(widget.videoFile)
      ..initialize().then((_) {
        setState(() {
          _initialized = true;
          _controller.play();
        });
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Video')),
      body: Center(
        child: _initialized
            ? AspectRatio(
                aspectRatio: _controller.value.aspectRatio,
                child: VideoPlayer(_controller),
              )
            : CustomCircularProgressIndicator(),
      ),
      floatingActionButton: _initialized
          ? FloatingActionButton(
              onPressed: () {
                setState(() {
                  _controller.value.isPlaying
                      ? _controller.pause()
                      : _controller.play();
                });
              },
              child: Icon(
                _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
              ),
            )
          : null,
    );
  }
}
